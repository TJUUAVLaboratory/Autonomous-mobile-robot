#include "global_navi/global_navi.h"
#include <boost/thread.hpp>


namespace global_navi
{
    GlobalNavi::GlobalNavi(tf::TransformListener& tf) :
        tf_(tf),
        action_server_(NULL),
        global_costmap_ros_(NULL),
        baseGlobalPlanner_Load_("nav_core", "BaseGlobalPlanner"),
        planner_plan_(NULL), latest_plan_(NULL)
    {
        //收到一个goal 传递给action_server
        // action_server_ = new MoveBaseActionServer(ros::NodeHandle(), "global_action", boost::bind(&GlobalNavi::MoveBaseGoalCallback, this, _1), false);
        ros::NodeHandle private_nh("~");
        ros::NodeHandle nh;

        // global_planner plugin name
        std::string global_planner_name;
        private_nh.param("global_planner_plugin", global_planner_name, std::string("navfn::NavfnROS"));
        private_nh.param("globa_base_frame", global_frame_, std::string("/map"));
        private_nh.param("robot_base_frame", robot_base_frame_, std::string("base_link"));

        private_nh.param("global_planner_frequency", global_planner_frequency_, 0.5);
        private_nh.param("global_planner_patience", global_planner_patience_, 5.0);
        private_nh.param("max_planning_retries", max_planning_retries_, -1);  // disabled by default

         planner_plan_ = new std::vector<geometry_msgs::PoseStamped>();
         latest_plan_ = new std::vector<geometry_msgs::PoseStamped>();

         vel_pub_ = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
         ros::NodeHandle action_nh("move_base");
         


    }


    //get an goal callback
    void GlobalNavi::MoveBaseGoalCallback(const move_base_msgs::MoveBaseGoalPtr& move_base_goal)
    {
        ;
    }

}; //end of the namespace global_navi