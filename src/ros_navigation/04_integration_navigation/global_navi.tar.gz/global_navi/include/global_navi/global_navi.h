
#ifndef GLOBAL_NAVI_H
#define GLOBAL_NAVI_H

#include <string>
#include <vector>
#include <ros/ros.h>
#include <tf/transform_listener.h> 

#include <actionlib/server/simple_action_server.h>
#include <move_base_msgs/MoveBaseAction.h>

//global costmap
#include "../../02_mapping/costmap_2d/include/costmap_2d/costmap_2d_ros.h"

//全局路径规划
#include <pluginlib/class_loader.h>
#include "../../03_planning/nav_core/include/nav_core/base_global_planner.h"
#include "../../03_planning/navfn/include/navfn/navfn.h"

namespace global_navi
{
    // action
    typedef actionlib::SimpleActionServer<move_base_msgs::MoveBaseAction> MoveBaseActionServer; 

    enum NaviState {
        PLANNING,
        CONTROLLING
    };

class GlobalNavi
{
public:

    GlobalNavi(tf::TransformListener& tf);

    ~GlobalNavi();

    //get an goal callback
    void MoveBaseGoalCallback(const move_base_msgs::MoveBaseGoalPtr& move_base_goal);


private:
    tf::TransformListener& tf_;
    MoveBaseActionServer* action_server_;

    boost::shared_ptr<nav_core::BaseGlobalPlanner> global_planner_;
    costmap_2d::Costmap2DROS *global_costmap_ros_;

    std::string  global_frame_, robot_base_frame_;
    tf::Stamped<tf::Pose> global_pose_;

    // global planner param
    double global_planner_frequency_;
    double global_planner_patience_;
    double inscribed_radius_;
    double circumscribed_radius_;

    int32_t  max_planning_retries_;
    int32_t  planning_retries_;

    ros::Publisher global_path_pub_, vel_pub_;
    ros::Subscriber goal_sub_;
    ros::Subscriber lasre_sub_;

    NaviState global_nave_state;
    ros::Time last_valid_plan_;

    pluginlib::ClassLoader<nav_core::BaseGlobalPlanner> baseGlobalPlanner_Load_;

    std::vector<geometry_msgs::PoseStamped> *planner_plan_;
    std::vector<geometry_msgs::PoseStamped> *latest_plan_;

    
    //多线程    
    boost::recursive_mutex global_planner_mutex_;
    boost::condition_variable_any global_planner_cond_;
    boost::thread *global_planner_thread_;


}; //end of the GlobalNavi class    

}; // end of namespace



#endif